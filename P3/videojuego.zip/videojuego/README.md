La raqueta mueve con las flechas del teclado. 

Al apretar la tecla espacio aparece la pelota y comienza la partida.  

La puntuación de cada ladrillo es de 1.

Se dispone en total de 3 vidas. 

Cada vez que no se consiga golpear la bola el jugador pierde una vida. 

En la parte superior  figuran la puntuación y el número de vidas que quedan.

Como suplemento he añadido música de gameover que suena cuando el jugador pierde la pártida y música de victoria que suena en el caso de que el jugador gane la partida, además de aparecer su respectivo mensaje. También he añadido unas pequeñas instrucciones.