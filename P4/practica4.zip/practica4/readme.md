A la  imagen original se le aplicará un filtro, que se seleccionará entre tres filtros disponibles y se generará una segunda imagen con el resultado.
Los filtros se seleccionarán mediante dos botones.

Uno transformará la imagen a escala de grises.

Uno transformará la imagen a espejo.

El otro es un filtro de color, por umbrales.

Dispondrá de 3 barras deslizantes para seleccionar los umbrales de cada color: rojo, verde, azul.

Un umbral de 0 hace que ese color en concreto desaparezca.

Si el filtro seleccionado actualmente es el de grises, los deslizadores no tendrán ningún efecto.

Sólo funcionarán cuando esté activado el filtro de color.